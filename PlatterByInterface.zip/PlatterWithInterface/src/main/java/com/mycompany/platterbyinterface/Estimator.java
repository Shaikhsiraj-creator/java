package com.mycompany.platterbyinterface;
public class Estimator {
public static void printShapeAEstimate(ShapeA shapeA){
      System.out.println("solid surface area : "+shapeA.getSolidSurfaceArea());
          System.out.println("Vecant area : "+shapeA.getVecantArea());
            System.out.println("Outer Boundry : "+shapeA.getOuterBoundry());
              System.out.println("Inner Boundry : "+shapeA.getInnerBoundry());
}
public static void printShapeBEstimate(ShapeB shapeB){
      System.out.println("solid surface area : "+shapeB.getSolidSurfaceArea());
          System.out.println("Vecant area : "+shapeB.getVecantArea());
            System.out.println("Outer Boundry : "+shapeB.getOuterBoundry());
              System.out.println("Inner Boundry : "+shapeB.getInnerBoundry());
}
public static void printShapeCEstimate(ShapeC shapeC){
      System.out.println("solid surface area : "+shapeC.getSolidSurfaceArea());
          System.out.println("Vecant area : "+shapeC.getVecantArea());
            System.out.println("Outer Boundry : "+shapeC.getOuterBoundry());
              System.out.println("Inner Boundry : "+shapeC.getInnerBoundry());
}
public static void printShapeDEstimate(ShapeD shapeD){
      System.out.println("solid surface area : "+shapeD.getSolidSurfaceArea());
          System.out.println("Vecant area : "+shapeD.getVecantArea());
            System.out.println("Outer Boundry : "+shapeD.getOuterBoundry());
              System.out.println("Inner Boundry : "+shapeD.getInnerBoundry());
}
public static void printShapeEEstimate(ShapeE shapeE){
      System.out.println("solid surface area : "+shapeE.getSolidSurfaceArea());
          System.out.println("Vecant area : "+shapeE.getVecantArea());
            System.out.println("Outer Boundry : "+shapeE.getOuterBoundry());
              System.out.println("Inner Boundry : "+shapeE.getInnerBoundry());
}
public static void printShapeFEstimate(ShapeF shapeF){
      System.out.println("solid surface area : "+shapeF.getSolidSurfaceArea());
          System.out.println("Vecant area : "+shapeF.getVecantArea());
            System.out.println("Outer Boundry : "+shapeF.getOuterBoundry());
              System.out.println("Inner Boundry : "+shapeF.getInnerBoundry());
}
public static void printShapeGEstimate(ShapeG shapeG){
      System.out.println("solid surface area : "+shapeG.getSolidSurfaceArea());
          System.out.println("Vecant area : "+shapeG.getVecantArea());
            System.out.println("Outer Boundry : "+shapeG.getOuterBoundry());
              System.out.println("Inner Boundry : "+shapeG.getInnerBoundry());
}
}
