package com.mycompany.platterbyinterface;
public interface Platter {
public double getSolidSurfaceArea();
public double getVecantArea();
public double getOuterBoundry();
public double getInnerBoundry();
}
