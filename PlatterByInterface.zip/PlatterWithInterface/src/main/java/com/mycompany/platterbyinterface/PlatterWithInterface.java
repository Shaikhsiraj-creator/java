
package com.mycompany.platterbyinterface;
public class PlatterWithInterface {

    public static void main(String[] args) {
    String shape="C";
    double length=7;
    double breadth=5;
    double radius=2;
    if(shape=="A"){
        ShapeA shapeA=new ShapeA(length,breadth,radius);
      Estimator.printShapeAEstimate(shapeA);
    }
    else if(shape=="B"){
        ShapeB shapeB=new ShapeB(radius,length,breadth);
        Estimator.printShapeBEstimate(shapeB);
    }
    else if(shape=="C"){
        ShapeC shapeC=new ShapeC(length,breadth,radius);
        Estimator.printShapeCEstimate(shapeC);
    }
    else if(shape=="D"){
        ShapeD shapeD=new ShapeD( length,radius);
        Estimator.printShapeDEstimate(shapeD);
    }
    else  if(shape=="E"){
        ShapeE shapeE=new ShapeE(length,breadth,radius,radius);
        Estimator.printShapeEEstimate(shapeE);
    }
    else if(shape=="F"){
        ShapeF shapeF=new ShapeF(length,breadth,radius);
        Estimator.printShapeFEstimate(shapeF);
    }
    else if(shape=="G"){
        ShapeG shapeG=new ShapeG(length,radius);
        Estimator.printShapeGEstimate(shapeG);
    }
    
    
    
    
    }
}
