package com.mycompany.platterbyinterface;
import static java.lang.Math.PI;
public class ShapeA implements Platter {
private double length;
private double breadth;
private double radius;

    public ShapeA(double length, double breadth, double radius) {
        this.length = length;
        this.breadth = breadth;
        this.radius = radius;
    }

    @Override
    public double getSolidSurfaceArea() {
    return (length*breadth)-(3*PI*radius*radius); 
    }

    @Override
    public double getVecantArea() {
        return (3*PI*radius*radius);
    }

    @Override
    public double getOuterBoundry() {
    return (2*(length+breadth));
    }

    @Override
    public double getInnerBoundry() {
    return (3*2*PI*radius);
    }
    
}
