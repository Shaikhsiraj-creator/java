package com.mycompany.platterbyinterface;
import static java.lang.Math.PI;
public class ShapeB implements Platter {
    private double radius;
    private double length;
    private double breadth;

    public ShapeB(double radius, double length, double breadth) {
        this.radius = radius;
        this.length = length;
        this.breadth = breadth;
    }
    @Override
    public double getSolidSurfaceArea() {
return ((PI*radius*radius)-(length*breadth));
    }
    @Override
    public double getVecantArea() {
        return (length*breadth);
    }
    @Override
    public double getOuterBoundry() {
        return (2*PI*radius);
    }
    @Override
    public double getInnerBoundry() {
        return (2*(length+breadth));
    }
    
}
