package com.mycompany.platterbyinterface;
import static java.lang.Math.PI;
public class ShapeC implements Platter {
private double length;
private double breadth;
private double radius;

    public ShapeC(double length, double breadth, double radius) {
        this.length = length;
        this.breadth = breadth;
        this.radius = radius;
    }

    @Override
    public double getSolidSurfaceArea() {
    return (length*breadth)-(2*PI*radius*radius); 
    }

    @Override
    public double getVecantArea() {
        return (2*PI*radius*radius);
    }

    @Override
    public double getOuterBoundry() {
    return (2*(length+breadth));
    }

    @Override
    public double getInnerBoundry() {
    return (2*2*PI*radius);
    }  
}
