package com.mycompany.platterbyinterface;

import static java.lang.Math.PI;

public class ShapeD implements Platter{
    private double radius1;
    private double radius2;

    public ShapeD(double radius1, double radius2) {
        this.radius1 = radius1;
        this.radius2 = radius2;
    }
 @Override
    public double getSolidSurfaceArea() {
    return ((PI*radius1*radius1)-(2*PI*radius2*radius2));
    }
    @Override
    public double getVecantArea() {
        return (2*PI*radius2*radius2);
    }
    @Override
    public double getOuterBoundry() {
        return (2*PI*radius1);
    }
    @Override
    public double getInnerBoundry() {
        return (2*2*PI*radius2);
    }
    
}
