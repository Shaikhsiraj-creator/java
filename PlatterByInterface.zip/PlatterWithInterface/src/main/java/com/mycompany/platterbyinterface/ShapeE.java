package com.mycompany.platterbyinterface;
import static java.lang.Math.PI;
public class ShapeE implements Platter {
    private double length;
    private double breadth;
    private double radius;
    private double side;

    public ShapeE(double length, double breadth, double radius, double side) {
        this.length = length;
        this.breadth = breadth;
        this.radius = radius;
        this.side = side;
    }
    @Override
    public double getSolidSurfaceArea() {
        return ((length*breadth)-(4*PI*radius*radius)-(4*side*side));
    }
    @Override
    public double getVecantArea() {
        return ((4*PI*radius*radius)+(4*side*side));
    }
    @Override
    public double getOuterBoundry() {
        return (2*(length+breadth));
    }
    @Override
    public double getInnerBoundry() {
        return ((4*2*PI*radius)+(4*4*side));
    }
    
}
