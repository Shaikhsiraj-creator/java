package com.mycompany.platterbyinterface;
import static java.lang.Math.PI;
public class ShapeF implements Platter {
    private double length;
    private double breadth;
    private double radius;

    public ShapeF(double length, double breadth, double radius) {
        this.length = length;
        this.breadth = breadth;
        this.radius = radius;
    }

    public double getSolidSurfaceArea(){
        return ((length*breadth)-(PI*radius*radius));
    }
    public double getVecantArea() {
        return PI*radius*radius;
    }
    public double getOuterBoundry() {
    return (2*(length+breadth));
    }
    public double getInnerBoundry() {
        return (2*PI*radius);
    }
}
