package com.mycompany.platterbyinterface;

import static java.lang.Math.PI;

public class ShapeG implements Platter{
   private double radius1;
   private double radius2;

    public ShapeG(double radius1, double radius2) {
        this.radius1 = radius1;
        this.radius2 = radius2;
    }
    public double getSolidSurfaceArea() {
    return ((PI*radius1-radius1)-(4*PI*radius2*radius2));
    }
    public double getVecantArea() {
    return 4*PI*radius2*radius2;
    }
    public double getOuterBoundry() {
    return 2*PI*radius1;
    }
    public double getInnerBoundry() {
    return   2*PI*radius2;
    }
    
}
