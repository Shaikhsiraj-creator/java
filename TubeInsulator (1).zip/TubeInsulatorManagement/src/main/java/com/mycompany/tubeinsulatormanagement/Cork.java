package com.mycompany.tubeinsulatormanagement;

public class Cork {

    public Cylinder corkCylinder;

    public Cork(double radius, double height) {
        corkCylinder = new Cylinder(radius, height);
    }

    public double getCorkCapacity() {
        return corkCylinder.getCylinderVolume();
   }

}
