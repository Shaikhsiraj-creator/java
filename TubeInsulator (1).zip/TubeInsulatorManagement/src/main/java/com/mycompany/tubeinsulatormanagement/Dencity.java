package com.mycompany.tubeinsulatormanagement;

public class Dencity {

    final public static double glycerineDencity = 1.26;
    final public static double woodenDust = 0.3556;

}
