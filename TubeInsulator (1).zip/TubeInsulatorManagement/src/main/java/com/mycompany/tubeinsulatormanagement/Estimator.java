package com.mycompany.tubeinsulatormanagement;

public class Estimator {

    public static void printTubeInsulation(TubeInsulator tubeInsulator) {
        System.out.println(" ============= Property Description ============= \n");
        System.out.println("Tube Radius " + tubeInsulator.getTube().getTubeRadius());
        System.out.println("Tube Height " + tubeInsulator.getTube().getTubeHeight());
        System.out.println("Insulator Radius " + tubeInsulator.getInsulator().getInsulationRadius());
        System.out.println("Insulator Height " + tubeInsulator.getInsulator().getInsulationHeight());
        System.out.println("Left Cork Height " + tubeInsulator.getLeftCork().corkCylinder.getHeight());
        System.out.println("Left Cork Radius " + tubeInsulator.getLeftCork().corkCylinder.getRadius());
        System.out.println("Right Cork Height " + tubeInsulator.getRightCork().corkCylinder.getHeight());
        System.out.println("Right Cork Radius " + tubeInsulator.getRightCork().corkCylinder.getRadius());

        System.out.println(" ============= Capacity Description =============  \n");
        System.out.println("Tube Filling Capacity "+tubeInsulator.getTubeFillingCapacity());
        System.out.println("Insulation Area Volume "+tubeInsulator.getInsulationVolume());
        System.out.println("Left Cork Capacity "+tubeInsulator.getLeftCorkCapacity());
        System.out.println("Right Cork Capacity "+tubeInsulator.getRightCorkCapacity());
        System.out.println("Glycerine Weight "+Operations.getGlycerineCapacity(tubeInsulator.getTubeFillingCapacity()));
        System.out.println("Dust Weight "+Operations.getWoodenDustCapacity(tubeInsulator.getTubeFillingCapacity()));
    }
}
