package com.mycompany.tubeinsulatormanagement;

public class Insulator {

    private Cylinder tunnel;
    private Cylinder outerBoundry;

    public Insulator(double tunnelRadius, double tunnelHeight, double totalRadius, double totalHeight) {
        tunnel = new Cylinder(tunnelRadius, tunnelHeight);
        outerBoundry = new Cylinder(totalRadius, totalHeight);
    }

    public double getTunnelCapacity() {
        return tunnel.getCylinderVolume();
    }

    public double getOuterBoundryCapacity() {
        return outerBoundry.getCylinderVolume() - getTunnelCapacity();
    }

    public double getTunnelRadius() {
        return tunnel.getRadius();
    }

    public double getTunnelHeight() {
        return tunnel.getHeight();
    }

    public double getOuterBoundryRadius() {
        return outerBoundry.getRadius();
    }

    public double getOuterBoundryHeight() {
        return outerBoundry.getHeight();
    }

    public double getInsulationRadius() {
        return outerBoundry.getRadius() - tunnel.getRadius();
    }

    public double getInsulationHeight() {
        return outerBoundry.getHeight();
    }

}
