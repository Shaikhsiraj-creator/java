package com.mycompany.tubeinsulatormanagement;

public class Operations {

    public static double getGlycerineCapacity(double capacity) {
        return capacity * Dencity.glycerineDencity;
    }

    public static double getWoodenDustCapacity(double capacity) {
        return capacity * Dencity.woodenDust;
    }

}
