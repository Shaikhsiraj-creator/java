package com.mycompany.tubeinsulatormanagement;

public class Tube {

    private Cylinder cylinder;

    public Tube(double radius, double height) {
        cylinder = new Cylinder(radius, height);
    }

    public double getTubeCapacity() {
        return cylinder.getCylinderVolume();
    }

    public double getTubeRadius() {
        return cylinder.getRadius();
    }

    public double getTubeHeight() {
        return cylinder.getHeight();
    }

}
