package com.mycompany.tubeinsulatormanagement;

public class TubeInsulator {

    private Tube tube;
    private Insulator insulator;

    private Cork leftCork;
    private Cork rightCork;

    public Tube getTube() {
        return tube;
    }

    public void setTube(Tube tube) {
        this.tube = tube;
    }

    public Insulator getInsulator() {
        return insulator;
    }

    public void setInsulator(Insulator insulator) {
        this.insulator = insulator;
    }

    public Cork getLeftCork() {
        return leftCork;
    }

    public void setLeftCork(Cork leftCork) {
        this.leftCork = leftCork;
    }

    public Cork getRightCork() {
        return rightCork;
    }

    public void setRightCork(Cork rightCork) {
        this.rightCork = rightCork;
    }

    public TubeInsulator(double tubeRadius, double tubeHeight, double insulatorRadius, double insulatorHeight) {
        tube = new Tube(tubeRadius, tubeHeight);
        insulator = new Insulator(tubeRadius, tubeHeight, insulatorRadius, insulatorHeight);
        double leftCorkHeight = ((tubeHeight - insulatorHeight) / 2);
        double rightCorkHeight = ((tubeHeight - insulatorHeight) / 2);
        leftCork = new Cork(tubeRadius, leftCorkHeight);
        rightCork = new Cork(tubeRadius, rightCorkHeight);
    }

    public double getLeftCorkCapacity() {
        return leftCork.getCorkCapacity();
    }

    public double getRightCorkCapacity() {
        return rightCork.getCorkCapacity();
    }

    public double getTubeFillingCapacity() {
        return tube.getTubeCapacity() - leftCork.getCorkCapacity() - rightCork.getCorkCapacity();
    }

    public double getInsulationVolume() {
        return insulator.getOuterBoundryCapacity();
    }

}
