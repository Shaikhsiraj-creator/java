package com.mycompany.tubeinsulatormanagement;

public class TubeInsulatorManagement {
    
    public static void main(String[] args) {
        TubeInsulator tube = new TubeInsulator(3.5, 20, 10, 12);
        Estimator.printTubeInsulation(tube);
    }
}
