package com.mycompany.wordcountfinal;

import java.util.Comparator;
import java.util.TreeMap;
import java.util.TreeSet;

public class CharSortingDescending implements Comparator<Character> {

    TreeMap<Character, Integer> wordCount = new TreeMap();

    public CharSortingDescending(TreeMap<Character, Integer> wordCount) {
        this.wordCount = wordCount;
    }

    @Override
    public int compare(Character o1, Character o2) {

        if (wordCount.get(o1) < wordCount.get(o2)) {
            return 1;
        } else {
            return -1;
        }
    }

}
