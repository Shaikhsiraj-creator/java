package com.mycompany.wordcountfinal;

import java.io.FileNotFoundException;
import java.util.ArrayList;

public class DataCleaning {

    public static String removeSymbols(String inputString) throws FileNotFoundException {
        char strArray[] = inputString.toCharArray();
        ArrayList<Character> symbols = FileOperations.getSymbols("F:\\symbol.txt");
        ArrayList<Character> inputCharList = new ArrayList<Character>();

        for (char c : strArray) {
            inputCharList.add(c);
        }
        inputCharList.removeAll(symbols);

        inputString = "";

        for (Character character : inputCharList) {
            inputString = inputString.concat(String.valueOf(character));
        }
        return inputString;
    }

    public static ArrayList<String> removeStopword(String inputString) throws FileNotFoundException {
        ArrayList<String> inputList = Operations.getList(inputString);
        ArrayList<String> stopwordList = FileOperations.getStopword("F:\\stopword.txt");
        inputList.removeAll(stopwordList);

        ArrayList<String> specialWord = new ArrayList<String>();
        specialWord.add("");
        specialWord.add("  ");
        specialWord.add("    ");
        specialWord.add("‚¹");
        specialWord.add("€“");

        specialWord.add(" ");
        inputList.removeAll(specialWord);
        return inputList;
    }

}
