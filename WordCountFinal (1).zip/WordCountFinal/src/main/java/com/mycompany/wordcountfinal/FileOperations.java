package com.mycompany.wordcountfinal;

import java.util.*;
import java.io.*;

public class FileOperations {

    public static String getInputFileContent(String filePath) throws FileNotFoundException {
        File file = new File(filePath);
        Scanner sc = new Scanner(file);
        String input = "";
        while (sc.hasNext()) {
            input = input.concat(sc.next()).concat(" ");
        }
        return input.toLowerCase();
    }

    public static ArrayList<String> getStopword(String filePath) throws FileNotFoundException {
        File file = new File(filePath);
        Scanner sc = new Scanner(file);
        ArrayList<String> list = new ArrayList<>();
        while (sc.hasNext()) {
            list.add(sc.next());
        }
        return list;
    }

    public static ArrayList<Character> getSymbols(String filePath) throws FileNotFoundException {
        File file = new File(filePath);
        Scanner sc = new Scanner(file);
        ArrayList<Character> list = new ArrayList<>();
        while (sc.hasNext()) {
            list.add(sc.next().charAt(0));
        }
        return list;
    }

}
