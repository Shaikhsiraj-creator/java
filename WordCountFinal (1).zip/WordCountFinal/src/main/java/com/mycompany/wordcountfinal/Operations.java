package com.mycompany.wordcountfinal;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.TreeMap;

public class Operations {

    public static ArrayList<String> getList(String inputString) {
        String input[] = inputString.split(" ");

        ArrayList<String> inputList = new ArrayList<>();

        for (String string : input) {
            inputList.add(string);
        }

        return inputList;
    }

    public static void print(Collection<String> list) {
        for (String string : list) {
            System.out.println(string);
        }
    }

    public static void printChar(TreeMap<Character, Integer> wordCount) {
        for (Map.Entry<Character, Integer> entry : wordCount.entrySet()) {
            Character key = entry.getKey();
            Integer value = entry.getValue();
            System.out.println(key + " " + value);
        }
    }

    public static void print(TreeMap<String, Integer> wordCount){
        for (Map.Entry<String, Integer> entry : wordCount.entrySet()) {
            String key = entry.getKey();
            Integer value = entry.getValue();
            System.out.println(key + " " + value);
        }
    }

}
