package com.mycompany.wordcountfinal;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class UserOperations {

    public static TreeSet<String> getUniqueWordList(ArrayList<String> duplicateWordList) {
        TreeSet<String> uniqueList = new TreeSet<>(duplicateWordList);
        return uniqueList;
    }

    public static TreeMap<String, Integer> getWordCount(ArrayList<String> duplicateWordList) {
        TreeSet<String> uniqueList = getUniqueWordList(duplicateWordList);

        TreeMap<String, Integer> wordCount = new TreeMap<String, Integer>();
        for (String string : uniqueList) {
            int count = Collections.frequency(duplicateWordList, string);
            wordCount.put(string, count);
        }
        Comparator<String> cmp = new WordSortingAscending(wordCount);
        TreeMap<String, Integer> newWordCount = new TreeMap<String, Integer>(cmp);
        newWordCount.putAll(wordCount);
        return newWordCount;
    }

    public static TreeMap<String, Integer> getTop5(ArrayList<String> duplicateWordList) {
        TreeMap<String, Integer> uniqueWordCount = getWordCount(duplicateWordList);
        Set<Map.Entry<String, Integer>> setCount = uniqueWordCount.entrySet();

        Iterator<Map.Entry<String, Integer>> iteration = setCount.iterator();

        TreeMap<String, Integer> top5 = new TreeMap<String, Integer>();

        int count = 0;
        while (iteration.hasNext() && count < 5) {
            Map.Entry<String, Integer> nextValue = iteration.next();
            top5.put(nextValue.getKey(), nextValue.getValue());
            count++;
        }

        Comparator<String> cmp = new WordSortingDescending(top5);
        TreeMap<String, Integer> newTop5 = new TreeMap<String, Integer>(cmp);
        newTop5.putAll(top5);
        return newTop5;

    }

    public static TreeMap<String, Integer> getTop10(ArrayList<String> duplicateWordList) {
        TreeMap<String, Integer> uniqueWordCount = getWordCount(duplicateWordList);
        Set<Map.Entry<String, Integer>> setCount = uniqueWordCount.entrySet();

        Iterator<Map.Entry<String, Integer>> iteration = setCount.iterator();

        TreeMap<String, Integer> Top10 = new TreeMap<String, Integer>();

        int count = 0;
        while (iteration.hasNext() && count < 10) {
            Map.Entry<String, Integer> nextValue = iteration.next();
            Top10.put(nextValue.getKey(), nextValue.getValue());
            count++;
        }

        Comparator<String> cmp = new WordSortingDescending(Top10);
        TreeMap<String, Integer> newTop10 = new TreeMap<String, Integer>(cmp);
        newTop10.putAll(Top10);
        return newTop10;

    }

    public static TreeMap<String, Integer> getBottom5(ArrayList<String> duplicateWordList) {
        TreeMap<String, Integer> uniqueWordCount1 = getWordCount(duplicateWordList);
        TreeMap<String, Integer> uniqueWordCount = new TreeMap<>();

        for (Map.Entry<String, Integer> entry : uniqueWordCount1.entrySet()) {
            String key = entry.getKey();
            Integer value = entry.getValue();
            uniqueWordCount.put(key, value);
        }
        Comparator<String> cmp1 = new WordSortingAscending(uniqueWordCount);
        TreeMap<String, Integer> newWordCount = new TreeMap<String, Integer>(cmp1);
        newWordCount.putAll(uniqueWordCount);

        Set<Map.Entry<String, Integer>> setCount = newWordCount.entrySet();

        Iterator<Map.Entry<String, Integer>> iteration = setCount.iterator();

        TreeMap<String, Integer> Bottom5 = new TreeMap<String, Integer>();

        int count = 0;
        while (iteration.hasNext() && count < 5) {
            Map.Entry<String, Integer> nextValue = iteration.next();
            Bottom5.put(nextValue.getKey(), nextValue.getValue());
            count++;
        }

        Comparator<String> cmp = new WordSortingAscending(Bottom5);
        TreeMap<String, Integer> newBottom5 = new TreeMap<String, Integer>(cmp);
        newBottom5.putAll(Bottom5);
        return newBottom5;

    }

    public static TreeMap<String, Integer> getBottom10(ArrayList<String> duplicateWordList) {
        TreeMap<String, Integer> uniqueWordCount1 = getWordCount(duplicateWordList);
        TreeMap<String, Integer> uniqueWordCount = new TreeMap<>();

        for (Map.Entry<String, Integer> entry : uniqueWordCount1.entrySet()) {
            String key = entry.getKey();
            Integer value = entry.getValue();
            uniqueWordCount.put(key, value);
        }
        Comparator<String> cmp1 = new WordSortingAscending(uniqueWordCount);
        TreeMap<String, Integer> newWordCount = new TreeMap<String, Integer>(cmp1);
        newWordCount.putAll(uniqueWordCount);

        Set<Map.Entry<String, Integer>> setCount = newWordCount.entrySet();

        Iterator<Map.Entry<String, Integer>> iteration = setCount.iterator();

        TreeMap<String, Integer> Bottom10 = new TreeMap<String, Integer>();

        int count = 0;
        while (iteration.hasNext() && count < 10) {
            Map.Entry<String, Integer> nextValue = iteration.next();
            Bottom10.put(nextValue.getKey(), nextValue.getValue());
            count++;
        }

        Comparator<String> cmp = new WordSortingAscending(Bottom10);
        TreeMap<String, Integer> newBottom10 = new TreeMap<String, Integer>(cmp);
        newBottom10.putAll(Bottom10);
        return newBottom10;

    }

    public static TreeMap<Character, Integer> getTopChar5(ArrayList<String> duplicateWordList) {
        TreeSet<String> uniqueWordCount = getUniqueWordList(duplicateWordList);

        String uniqueString = "";

        for (String string : uniqueWordCount) {
            uniqueString = uniqueString.concat(string);
        }

        char inputChar[] = uniqueString.toCharArray();

        ArrayList<Character> inputCharList = new ArrayList<>();

        for (char c : inputChar) {
            inputCharList.add(c);
        }

        ArrayList<Character> alphabet = new ArrayList<>();

        for (int i = 97; i <= 122; i++) {
            alphabet.add((char) i);
        }

        TreeMap<Character, Integer> charCount = new TreeMap<Character, Integer>();

        for (Character character : alphabet) {
            int count = Collections.frequency(inputCharList, character);
            charCount.put(character, count);
        }

        Comparator<Character> cmp1 = new CharSortingDescending(charCount);
        TreeMap<Character, Integer> newCharCount = new TreeMap<Character, Integer>(cmp1);
        newCharCount.putAll(charCount);

        Set<Map.Entry<Character, Integer>> setCount = newCharCount.entrySet();

        Iterator<Map.Entry<Character, Integer>> iteration = setCount.iterator();

        TreeMap<Character, Integer> top5Char = new TreeMap<Character, Integer>();

        int count = 0;
        while (iteration.hasNext() && count < 5) {
            Map.Entry<Character, Integer> nextValue = iteration.next();
            top5Char.put(nextValue.getKey(), nextValue.getValue());
            count++;
        }

        Comparator<Character> cmp = new CharSortingDescending(top5Char);
        TreeMap<Character, Integer> newBottom5 = new TreeMap<Character, Integer>(cmp);
        newBottom5.putAll(top5Char);
        return newBottom5;

    }

    public static TreeMap<Character, Integer> getTopChar10(ArrayList<String> duplicateWordList) {
        TreeSet<String> uniqueWordCount = getUniqueWordList(duplicateWordList);

        String uniqueString = "";

        for (String string : uniqueWordCount) {
            uniqueString = uniqueString.concat(string);
        }

        char inputChar[] = uniqueString.toCharArray();

        ArrayList<Character> inputCharList = new ArrayList<>();

        for (char c : inputChar) {
            inputCharList.add(c);
        }

        ArrayList<Character> alphabet = new ArrayList<>();

        for (int i = 97; i <= 122; i++) {
            alphabet.add((char) i);
        }

        TreeMap<Character, Integer> charCount = new TreeMap<Character, Integer>();

        for (Character character : alphabet) {
            int count = Collections.frequency(inputCharList, character);
            charCount.put(character, count);
        }

        Comparator<Character> cmp1 = new CharSortingDescending(charCount);
        TreeMap<Character, Integer> newCharCount = new TreeMap<Character, Integer>(cmp1);
        newCharCount.putAll(charCount);

        Set<Map.Entry<Character, Integer>> setCount = newCharCount.entrySet();

        Iterator<Map.Entry<Character, Integer>> iteration = setCount.iterator();

        TreeMap<Character, Integer> top10Char = new TreeMap<Character, Integer>();

        int count = 0;
        while (iteration.hasNext() && count < 10) {
            Map.Entry<Character, Integer> nextValue = iteration.next();
            top10Char.put(nextValue.getKey(), nextValue.getValue());
            count++;
        }

        Comparator<Character> cmp = new CharSortingDescending(top10Char);
        TreeMap<Character, Integer> newBottom10 = new TreeMap<Character, Integer>(cmp);
        newBottom10.putAll(top10Char);
        return newBottom10;

    }

    public static TreeMap<Character, Integer> getBottomChar5(ArrayList<String> duplicateWordList) {
        TreeSet<String> uniqueWordCount = getUniqueWordList(duplicateWordList);

        String uniqueString = "";

        for (String string : uniqueWordCount) {
            uniqueString = uniqueString.concat(string);
        }

        char inputChar[] = uniqueString.toCharArray();

        ArrayList<Character> inputCharList = new ArrayList<>();

        for (char c : inputChar) {
            inputCharList.add(c);
        }

        ArrayList<Character> alphabet = new ArrayList<>();

        for (int i = 97; i <= 122; i++) {
            alphabet.add((char) i);
        }

        TreeMap<Character, Integer> charCount = new TreeMap<Character, Integer>();

        for (Character character : alphabet) {
            int count = Collections.frequency(inputCharList, character);
            charCount.put(character, count);
        }

        Comparator<Character> cmp1 = new CharSortingAscending(charCount);
        TreeMap<Character, Integer> newCharCount = new TreeMap<Character, Integer>(cmp1);
        newCharCount.putAll(charCount);

        Set<Map.Entry<Character, Integer>> setCount = newCharCount.entrySet();

        Iterator<Map.Entry<Character, Integer>> iteration = setCount.iterator();

        TreeMap<Character, Integer> Bottom5Char = new TreeMap<Character, Integer>();

        int count = 0;
        while (iteration.hasNext() && count < 5) {
            Map.Entry<Character, Integer> nextValue = iteration.next();
            Bottom5Char.put(nextValue.getKey(), nextValue.getValue());
            count++;
        }

        Comparator<Character> cmp = new CharSortingAscending(Bottom5Char);
        TreeMap<Character, Integer> newBottom5 = new TreeMap<Character, Integer>(cmp);
        newBottom5.putAll(Bottom5Char);
        return newBottom5;

    }

    public static TreeMap<Character, Integer> getBottomChar10(ArrayList<String> duplicateWordList) {
        TreeSet<String> uniqueWordCount = getUniqueWordList(duplicateWordList);

        String uniqueString = "";

        for (String string : uniqueWordCount) {
            uniqueString = uniqueString.concat(string);
        }

        char inputChar[] = uniqueString.toCharArray();

        ArrayList<Character> inputCharList = new ArrayList<>();

        for (char c : inputChar) {
            inputCharList.add(c);
        }

        ArrayList<Character> alphabet = new ArrayList<>();

        for (int i = 97; i <= 122; i++) {
            alphabet.add((char) i);
        }

        TreeMap<Character, Integer> charCount = new TreeMap<Character, Integer>();

        for (Character character : alphabet) {
            int count = Collections.frequency(inputCharList, character);
            charCount.put(character, count);
        }

        Comparator<Character> cmp1 = new CharSortingAscending(charCount);
        TreeMap<Character, Integer> newCharCount = new TreeMap<Character, Integer>(cmp1);
        newCharCount.putAll(charCount);

        Set<Map.Entry<Character, Integer>> setCount = newCharCount.entrySet();

        Iterator<Map.Entry<Character, Integer>> iteration = setCount.iterator();

        TreeMap<Character, Integer> Bottom10Char = new TreeMap<Character, Integer>();

        int count = 0;
        while (iteration.hasNext() && count < 10) {
            Map.Entry<Character, Integer> nextValue = iteration.next();
            Bottom10Char.put(nextValue.getKey(), nextValue.getValue());
            count++;
        }

        Comparator<Character> cmp = new CharSortingAscending(Bottom10Char);
        TreeMap<Character, Integer> newBottom10 = new TreeMap<Character, Integer>(cmp);
        newBottom10.putAll(Bottom10Char);
        return newBottom10;

    }

}
