package com.mycompany.wordcountfinal;

import java.io.FileNotFoundException;
import java.util.ArrayList;

public class WordCountFinal {

    public static void main(String[] args) throws FileNotFoundException {

        String input = FileOperations.getInputFileContent("F:\\input.txt");
        input = DataCleaning.removeSymbols(input);
        ArrayList<String> deplicateWordList = DataCleaning.removeStopword(input);
        System.out.println("------------Duplicate Word List-----------");
        Operations.print(deplicateWordList);
        System.out.println("------------Unique Word List-----------");
        Operations.print(deplicateWordList);
        System.out.println("------------Word Count-----------");
        Operations.print(UserOperations.getWordCount(deplicateWordList));

        System.out.println("------------Top 5 Word Count-----------");
        Operations.print(UserOperations.getTop5(deplicateWordList));
        System.out.println("------------Top 10 Word Count-----------");
        Operations.print(UserOperations.getTop10(deplicateWordList));

        System.out.println("------------Bottom 5 Word Count-----------");
        Operations.print(UserOperations.getBottom5(deplicateWordList));
        System.out.println("------------Bottom 10 Word Count-----------");
        Operations.print(UserOperations.getBottom10(deplicateWordList));

        System.out.println("------------Top 5 Char Count-----------");
        Operations.printChar(UserOperations.getTopChar5(deplicateWordList));
        System.out.println("------------Top 10 Char Count-----------");
        Operations.printChar(UserOperations.getTopChar10(deplicateWordList));

        System.out.println("------------Top 5 Char Count-----------");
        Operations.printChar(UserOperations.getBottomChar5(deplicateWordList));
        System.out.println("------------Top 10 Char Count-----------");
        Operations.printChar(UserOperations.getBottomChar10(deplicateWordList));

    }

}
