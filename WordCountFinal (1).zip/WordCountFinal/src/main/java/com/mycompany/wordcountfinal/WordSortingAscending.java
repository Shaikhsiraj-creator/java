package com.mycompany.wordcountfinal;

import java.util.Comparator;
import java.util.TreeMap;
import java.util.TreeSet;

public class WordSortingAscending implements Comparator<String> {

    TreeMap<String, Integer> wordCount = new TreeMap();

    public WordSortingAscending(TreeMap<String, Integer> wordCount) {
        this.wordCount = wordCount;
    }

    @Override
    public int compare(String o1, String o2) {

        if (wordCount.get(o1) > wordCount.get(o2)) {
            return 1;
        } else {
            return -1;
        }
    }

}
